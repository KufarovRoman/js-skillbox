if (cardInserted && amount <= balance) {
  console.log("Операция выполняется");
} else {
  console.log("Операция отклонена");
}
