function getAverage(a, b, c) {
  return (a + b + c) / 3;
}
