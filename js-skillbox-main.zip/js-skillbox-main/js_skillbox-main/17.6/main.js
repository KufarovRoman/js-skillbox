import { initRouter } from './modules/router.js';

document.addEventListener('DOMContentLoaded', () => {
    initRouter();
});