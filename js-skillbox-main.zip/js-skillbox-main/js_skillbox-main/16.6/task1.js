function hello() {
    console.log('Skill');
  }
  
  try {
    helo();
  } catch (error) {
    console.error(error);
  }
  
  console.log('complete');
